package com.ciservice.app.common.enumeration;

/**
 * @author YukiMizoguchi
 *
 */
public enum PredictResult {

  HUP, MUP, UP, KEEP, DOWN, MDOWN, HDOWN

}
