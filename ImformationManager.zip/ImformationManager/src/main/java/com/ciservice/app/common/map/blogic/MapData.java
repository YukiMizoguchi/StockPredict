package com.ciservice.app.common.map.blogic;

public interface MapData<E1, E2, E3> {

  E3 map(E1 e1, E2 e2);

}
