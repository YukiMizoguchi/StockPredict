package com.ciservice.app.common.constant;

/**
 * @author YukiMizoguchi
 *
 */
public class SGConst {

  // DB定義
  public static final String PROPERTIES_MONGPDB_BEAN_XML =
      "classpath:META-INF/spring/mongodb-config.xml";

}
